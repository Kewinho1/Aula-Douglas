const bcrypt = require('bcrypt');
const UserRepository = require('../repositories/userRepository');
const userRepository = require('../repositories/userRepository');

const SECRET_KEY = 'EUJALAVEIOMEUCARROREGULEIOSOM';

class UserService{
    async register (username, password, email){
        if (this.getByUserName(username)){
            throw new Error('Usuário já Cadastrado');
        }


        const hashedPassword = await bcrypt.hash(password, SECRET_KEY);
        const user = await userRepository.createUser({username, email, password: hashedPassword});
        return user;

    }
async getByUserName(username){
    return await userRepository.findByUserName(username);
}
async login(username,password){
    const user = this.getByUserName(username);
    if(!user){
        throw new Error('Usuario ou senha incorretos')
    }
    const hashedPassword= awaitbcrypt.hash(password, SECRET_KEY);
    const isPasswordValid = await bcrypt.compare(hashedPassword, user.password);
    if(!isPasswordValid){
        throw new Error('Usuario não encontrado!!!');
    }

    return true;
}
    async getUesers(){
        return await userRepository.findAll();
    }
}

module.exports = new UserService();